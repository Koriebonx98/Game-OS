import os
import subprocess
import sys
import json

OUTPUT_FILES = ["All.Games.json", "New.Games.json"]

def run_py_scripts_in_subfolders(base_dir):
    for folder in os.listdir(base_dir):
        folder_path = os.path.join(base_dir, folder)
        if os.path.isdir(folder_path):
            for file in os.listdir(folder_path):
                if (
                    file.endswith(".py")
                    and file.startswith("scrape_")
                    and file != "Download.py"
                ):
                    script_path = os.path.join(folder_path, file)
                    print(f"Running: {script_path}")
                    result = subprocess.run(
                        [sys.executable, os.path.basename(script_path)],
                        cwd=folder_path,
                        capture_output=True,
                        text=True
                    )
                    print(f"--- Output from {script_path} ---")
                    print(result.stdout)
                    if result.stderr:
                        print(f"--- Errors from {script_path} ---")
                        print(result.stderr)
                    print("---" * 10)

def collect_games_from_jsons(base_dir, json_name):
    games = []
    for folder in os.listdir(base_dir):
        folder_path = os.path.join(base_dir, folder)
        if os.path.isdir(folder_path):
            json_path = os.path.join(folder_path, json_name)
            if os.path.exists(json_path):
                try:
                    with open(json_path, "r", encoding="utf-8") as f:
                        data = json.load(f)
                        for entry in data:
                            name = entry.get("Name", "").strip()
                            url = entry.get("Url", "").strip().rstrip("/")
                            if name and url:
                                games.append({"Name": name, "Url": url})
                except Exception as e:
                    print(f"Error reading {json_path}: {e}")
    return games

def load_existing_json(path):
    if os.path.exists(path):
        with open(path, "r", encoding="utf-8") as f:
            try:
                return json.load(f)
            except Exception:
                return []
    return []

def merge_games(games):
    merged = {}
    for g in games:
        name = g["Name"]
        url = g["Url"]
        if not name or not url:
            continue
        if name not in merged:
            merged[name] = set()
        merged[name].add(url)
    out = []
    for name, urls in merged.items():
        url_list = sorted(urls)
        if len(url_list) == 1:
            out.append({"Name": name, "Url": url_list[0]})
        else:
            out.append({"Name": name, "Url": url_list})
    return out

def aggregate_one_json(json_name, base_dir):
    games = collect_games_from_jsons(base_dir, json_name)
    existing = load_existing_json(json_name)
    flat_existing = []
    for g in existing:
        name = g.get("Name")
        url = g.get("Url")
        if isinstance(url, list):
            for u in url:
                flat_existing.append({"Name": name, "Url": u.rstrip("/")})
        elif isinstance(url, str):
            flat_existing.append({"Name": name, "Url": url.rstrip("/")})
    all_games = flat_existing + games
    merged = merge_games(all_games)
    with open(json_name, "w", encoding="utf-8") as f:
        json.dump(merged, f, indent=2, ensure_ascii=False)
    print(f"[DONE] {len(merged)} unique games written to {json_name}. (Multiple URLs per game supported)")

def main():
    base_dir = os.path.dirname(os.path.abspath(__file__))
    run_py_scripts_in_subfolders(base_dir)
    for json_name in OUTPUT_FILES:
        aggregate_one_json(json_name, base_dir)

if __name__ == "__main__":
    main()