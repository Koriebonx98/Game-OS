import requests
import os
import urllib.parse
import json
import re

URLS = [
    "https://myrient.erista.me/files/Internet%20Archive/archiver_2020/wii-u-retail-nus-usa/",
    "https://myrient.erista.me/files/Internet%20Archive/archiver_2020/wii-u-download-nus-usa/"
]
OUTPUT_FILE = "WIIU.Myrient.json"

def clean_game_name(name):
    # Remove anything in square brackets [ ... ] and parentheses ( ... )
    name = re.sub(r"\s*\[.*?\]", "", name)
    name = re.sub(r"\s*\(.*?\)", "", name)
    return name.strip()

def fetch_7z_links(url):
    response = requests.get(url)
    response.raise_for_status()
    entries = []
    for line in response.text.splitlines():
        match = re.search(r'href="([^"]+\.7z)"', line, re.IGNORECASE)
        if match:
            href = match.group(1)
            name = urllib.parse.unquote(href)
            if name.lower().endswith(".7z"):
                name = name[:-3]
            clean_name = clean_game_name(name)
            full_url = url + href
            entries.append((clean_name, full_url))
    return entries

def main():
    # Read existing entries for deduplication and grouping
    games_dict = {}
    if os.path.isfile(OUTPUT_FILE):
        with open(OUTPUT_FILE, "r", encoding="utf-8") as f:
            try:
                existing_json = json.load(f)
                for entry in existing_json:
                    name = entry.get("Name", "").strip()
                    urls = entry.get("Url", [])
                    if name:
                        games_dict.setdefault(name, set()).update(urls)
            except Exception:
                pass

    for url in URLS:
        entries = fetch_7z_links(url)
        for name, link in entries:
            if name:
                games_dict.setdefault(name, set()).add(link)

    # Convert to required format
    all_entries = []
    for name in sorted(games_dict.keys(), key=lambda x: x.lower()):
        urls = sorted(games_dict[name])
        all_entries.append({
            "Name": name,
            "Url": urls
        })

    with open(OUTPUT_FILE, "w", encoding="utf-8") as f:
        json.dump(all_entries, f, indent=2, ensure_ascii=False)

    print(f"Wrote {len(all_entries)} unique cleaned game names to {OUTPUT_FILE}.")

if __name__ == "__main__":
    main()