import requests
import os
import urllib.parse
import json
import re

BASE_URL = "https://myrient.erista.me/files/Redump/Microsoft%20-%20Xbox/"
OUTPUT_FILE = "All.Xbox.Games.json"

def clean_game_name(name):
    # Remove anything in parentheses (including region/language info)
    return re.sub(r"\s*\(.*?\)", "", name).strip()

def fetch_zip_links(url):
    response = requests.get(url)
    response.raise_for_status()
    # The archive.org directory listing is a simple HTML table
    entries = []
    for line in response.text.splitlines():
        match = re.search(r'href="([^"]+\.zip)"', line, re.IGNORECASE)
        if match:
            href = match.group(1)
            name = urllib.parse.unquote(href)
            if name.lower().endswith(".zip"):
                name = name[:-4]
            clean_name = clean_game_name(name)
            full_url = url + href
            entries.append((clean_name, full_url))
    return entries

def main():
    # Read existing entries for deduplication and grouping
    games_dict = {}
    if os.path.isfile(OUTPUT_FILE):
        with open(OUTPUT_FILE, "r", encoding="utf-8") as f:
            try:
                existing_json = json.load(f)
                for entry in existing_json:
                    name = entry.get("Name", "").strip()
                    urls = entry.get("Url", [])
                    if name:
                        games_dict.setdefault(name, set()).update(urls)
            except Exception:
                pass

    entries = fetch_zip_links(BASE_URL)
    for name, url in entries:
        if name:
            games_dict.setdefault(name, set()).add(url)

    # Convert to required format
    all_entries = []
    for name in sorted(games_dict.keys(), key=lambda x: x.lower()):
        urls = sorted(games_dict[name])
        all_entries.append({
            "Name": name,
            "Url": urls
        })

    with open(OUTPUT_FILE, "w", encoding="utf-8") as f:
        json.dump(all_entries, f, indent=2, ensure_ascii=False)

    print(f"Wrote {len(all_entries)} unique cleaned game names to {OUTPUT_FILE}.")

if __name__ == "__main__":
    main()